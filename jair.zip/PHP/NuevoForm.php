<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = htmlspecialchars($_POST['nombre']);
    $apellido = htmlspecialchars($_POST['apellido']);
    $telefono = htmlspecialchars($_POST['telefono']);

    if (!empty($nombre) && !empty($apellido) && !empty($telefono)) {
        echo "<h1>Datos recibidos:</h1>";
        echo "<p><strong>Nombre:</strong> " . $nombre . "</p>";
        echo "<p><strong>Apellido:</strong> " . $apellido . "</p>";
        echo "<p><strong>Teléfono:</strong> " . $telefono . "</p>";
    } else {
        echo "<h1>Faltan datos</h1>";
        echo "<p>Por favor, completa todos los campos.</p>";
    }
} else {
    echo "<p>No se han recibido datos del formulario.</p>";
}

//conectarse a la base de datos
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "jair y erick";

try {
  $conn = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password); //dbname = $dbname eso esta viendo si de verdad esta conectada la base de datos con el archivo php
  // set the PDO error mode to exception
  $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
  echo "Conexion Exitosa, con PDO Orientada a Objetos, extencion de PHP </br> :";
} catch(PDOException $e) {
  echo "Conexion Fallida, con PDO Orientada a Objetos, extencion de PHP </br> " . $e->getMessage();
}

//funcion para insertar datos en la base de datos
function insertarUsuario($nombre, $apellido, $telefono) {
    try {
        $sql = "INSERT INTO usuarios (nombre, apellido, telefono) VALUES (:nombre, :apellido, :telefono)";
        $stmt = $conn->prepare($sql);
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':apellido', $apellido);
        $stmt->bindParam(':telefono', $telefono);

        if ($stmt->execute()) {
            echo "Datos insertados correctamente";
        }else {
            echo "Error al insertar datos";
        }
    } catch (PDOException $e) {
        echo "Error al insertar datos: " . $e->getMessage();
    }
}


//bloque de datos recibidos
$nombre = $apellido = $telefono = "";
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['nombre']) && isset($_POST['apellido']) && isset($_POST['telefono'])) {
        //asignar y limpiar variables
        $nombre = htmlspecialchars(trim($_POST['nombre']));
    }
}
?>


